# pixijs setup

## Getting started

First, install dependencies

`npm install`

Start dev server

`npm run start`

Build 

`npm run build`

Deploy github page 

`npm run deploy`
